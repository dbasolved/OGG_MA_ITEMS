#!/bin/bash

#variables

cd ~/Desktop/Software/bin
./charbench -c ../configs/SOE_Server_Side_V2.xml -cs //localhost:1521/oggoow19.oracle.com -dt thin -v users, tpm,tps,cpu
