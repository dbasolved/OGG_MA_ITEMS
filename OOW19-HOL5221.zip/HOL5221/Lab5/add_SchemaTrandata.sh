#!/bin/bash

#variables
vPass=$1
vASHost=localhost
vASPort=$2
vGGAlias=SGGATE

function _addSchemaTrandata {
        curl -X POST \
        https://$vASHost:$vASPort/services/v2/connections/OracleGoldenGate.$vGGAlias/trandata/schema \
        --user "oggadmin:"$vPass   \
	-k \
        -H 'Cache-Control: no-cache' \
        -d '{
            "operation":"add",
            "schemaName":"oggoow19.soe",
            "prepareCsnMode":"nowait"
        }' > /dev/null
}

function _main {
     _addSchemaTrandata
}

_main

