#!/bin/bash

#variables
vPass=$1
vASHost=localhost
vPort=$2
vGGUser=$3
vGGPass=$4
vGGAlias=SGGATE

function _createAlias {
     curl -X POST \
       https://$vASHost:$vPort/services/v2/credentials/OracleGoldenGate/$vGGAlias \
       --user "oggadmin:"$vPass   \
       -k \
       -H 'Cache-Control: no-cache' \
       -d '{
         "userid":"'$vGGUser'",
         "password":"'$vGGPass'"
     }' > /dev/null
}

function _main {
     _createAlias
}

_main

