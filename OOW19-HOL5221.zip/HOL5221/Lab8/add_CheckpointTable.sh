#!/bin/bash

#variables
vPass=$1
vASHost=localhost
vASPort=$2
vGGAlias=OracleGoldenGate.TGGATE

function _createCkptTbl {
     curl -s -X POST \
     https://$vASHost:$vASPort/services/v2/connections/$vGGAlias/tables/checkpoint \
       --user "oggadmin:"$vPass   \
       -k \
       -H 'Cache-Control: no-cache' \
       -d '{
               "operation":"add",
               "name":"ggate.checkpoints"
     }' > /dev/null
}

function _main {
     _createCkptTbl
}

_main
