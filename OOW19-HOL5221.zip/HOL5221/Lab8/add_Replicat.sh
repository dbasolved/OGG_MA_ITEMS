#!/bin/bash

#variables
vPass=$1
vASHost=localhost
vASPort=$2
vRepName=$3
vGGAlias=TGGATE

function _addReplicat {
    curl -X POST \
    https://$vASHost:$vASPort/services/v2/replicats/$vRepName \
    --user "oggadmin:"$vPass   \
    -k \
    -H 'Cache-Control: no-cache' \
    -d '{
        "description":"Integrated Replicat",
        "config":[
            "Replicat     '$vRepName'",
            "UseridAlias '$vGGAlias'",
            "dboptions enable_instantiation_filtering",
            "map oggoow19.soe.addresses,target soe.addresses, keycols(address_id);",
            "map oggoow19.soe.customers, target soe.customers, keycols(customer_id);",
            "map oggoow19.soe.orders, target soe.orders, keycols(order_id);",
            "map oggoow19.soe.order_items, target soe.order_items, keycols(order_id, line_item_id);",
            "map oggoow19.soe.card_details, target soe.card_details, keycols(card_id);",
            "map oggoow19.soe.logon, target soe.logon;",
            "map oggoow19.soe.product_information, target soe.product_information;",
            "map oggoow19.soe.inventories, target soe.inventories, keycols(product_id, warehouse_id);",
            "map oggoow19.soe.product_descriptions, target soe.product_descriptions;",
            "map oggoow19.soe.warehouses, target soe.warehouses;",
            "map oggoow19.soe.orderentry_metadata, target soe.orderentry_metadata;"
        ],
        "source":{
            "name":"ab"
        },
        "mode":{
            "type":"integrated"
        },
        "credentials":{
            "alias":"'$vGGAlias'"
        },
        "checkpoint":{
            "table":"ggate.checkpoints"
        },
        "status":"running"
    }' > /dev/null
}

function _main {
     _addReplicat
}

_main

